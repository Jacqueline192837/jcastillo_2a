/*
 * Class Data
 * @author Jacqueline
 *
 * Copyright (c) 2022-2023 UV. All Rights Reserved.
 */

/**
 * Clase para guardar la información en un array.
 *
 * @version 1.0 06 Abril 2022
 * @author Jacqueline Castillo
 */
public class Data {

    public Data() {
    }

    /**
     * @param data
     */

    public String[] saveData(String data) {
        // throw new UnsupportedOperationException();
        String[] arrData = data.split(",");
        return arrData;
    }

}