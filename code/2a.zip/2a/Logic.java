/*
 * Class Logic
 * @author Jacqueline
 *
 * Copyright (c) 2022-2023 UV. All Rights Reserved.
 */

/**
 * Clase logica, en la cual se instancian y 
 * ejecutan todas las clases del programa 2a.
 *
 * @version 1.0 06 Abril 2022
 * @author Jacqueline Castillo
 */
public class Logic {

    private int n;
    private String data;
    private String[] arrData;
    private int lCounter;
    public int mCounter;

    public Logic() {
    }

    public void logic2a() {
        
        Input myInput = new Input();
        Output myOut = new Output();
        
		Data myData = new Data();
		LineCounter myLCounter = new LineCounter();
		MethodCounter myMCounter = new MethodCounter();

        data = myInput.readData("C:\\Users\\Jacqueline\\OneDrive - Universidad Veracruzana\\Jacque\\8vo Semestre\\Aspectos Humanos ISW\\Clase\\Proyecto 2a\\Codificación\\2a\\App.java");

		arrData = myData.saveData(data);
        n = arrData.length;
        System.out.println("****************************************");
        System.out.println("    Total de Lineas  :  " + n);

        lCounter = myLCounter.countLines(arrData, n);
        System.out.println("    Lineas Logicas :  " + lCounter);

		mCounter = myMCounter.countMethods(arrData, n);
        System.out.println("\n    Total de Metodos :  " + mCounter);
        System.out.println("****************************************");

        myOut.writeData("C:\\Users\\Jacqueline\\OneDrive - Universidad Veracruzana\\Jacque\\8vo Semestre\\Aspectos Humanos ISW\\Clase\\Proyecto 2a\\Codificación\\out1.txt", "Número de lineas = " + lCounter + " Múmero de metodos = " + mCounter);
    }
}