/*
 * Class LineCounter
 * @author Jacqueline
 *
 * Copyright (c) 2022-2023 UV. All Rights Reserved.
 */

 /**
 * Clase de conteo de las lineas de codigo de un programa.
 *
 * @version 1.0 06 Abril 2022
 * @author Jacqueline Castillo
 */
public class LineCounter {
    
    public String arrData;
    private int totalLines = 0;

    public LineCounter() {
    }

    /**
     * @param dataList 
     * @param n
     */
    public int countLines(String[] dataList, int n) {
        for(int x = 0; x<n; x++){
            arrData = dataList[x].trim();
            if (!("".equals(arrData) || arrData.startsWith("//") || arrData.startsWith("}") || arrData.startsWith("/*") || arrData.startsWith("*/") || arrData.startsWith("*"))) {
                totalLines++;
            }
        }
        return totalLines;
    }
}